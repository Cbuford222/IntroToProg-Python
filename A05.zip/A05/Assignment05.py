# ------------------------------------------------------------------------------------------ #
# Title: Assignment05
# Desc: This assignment demonstrates using dictionaries, files, and exception handling
# Change Log: (Who, When, What)
#   RRoot,1/1/2030,Created Script
#   <Your Name Here>,<Date>, <Activity>
# ------------------------------------------------------------------------------------------ #
import json


# Define the Data Constants
MENU: str = '''
---- Course Registration Program ----
  Select from the following menu:  
    1. Register a Student for a Course.
    2. Show current data.  
    3. Save data to a file.
    4. Exit the program.
----------------------------------------- 
'''
# Define the Data Constants
FILE_NAME: str = "Enrollments.json"

# Define the Data Variables and constants
student_first_name: str = ''  # Holds the first name of a student entered by the user.
student_last_name: str = ''  # Holds the last name of a student entered by the user.
course_name: str = ''  # Holds the name of a course entered by the user.
json_data: str = ''
file = None  # Holds a reference to an opened file.
menu_choice: str  # Hold the choice made by the user.
student_data: dict = {}  # one row of student data
students: list = []  # a table of student data

with open(FILE_NAME, 'r') as file:
    student = json.load(file)
print(students)
# When the program starts, read the file data into a list of lists (table)
# Extract the data from the file
try:
    file = open(FILE_NAME, 'r')
    students =json.load(file)
    file.close()
except FileNotFoundError as e:
    print("The JSON file was not found \n")
    print("Technical Error")
    print("Create missing file")
    file = open(FILE_NAME, 'w')
    json.dump(students, file)
except JSONDecodeError:
    print("Data in file is not valid \nResetting it.") #error handling
    file = open(FILE_NAME, 'w')
    json.dump(students, file)
finally:
    if not file.closed:
        file.close()

# Present and Process the data
while (True):

    # Present the menu of choices
    print(MENU)
    menu_choice = input("What would you like to do: \n")

    # Input user data
    if menu_choice == "1":
        try:
            student_first_name = input("Enter the student's first name: ")
            if not student_first_name.isalpha():
                raise ValueError("\nThe first name should only contain letters.\n")
        except ValueError as e:
            print(e)
            print("Technical Error")
            print(e._doc_, type(e), sep='\n')
            if not student_first_name.isalpha():
                student_first_name = input("\nWhat is the student's first name?")
        try:
            student_last_name = input("Enter the student's last name: ")
            if not student_last_name.isalpha():
                raise ValueError("\nThe last name should only contain letters\n")
        except ValueError as e:
            print(e)
            print("Technical Error")
            print(e._doc_, type(e), sep='\n')
            if not student_last_name.isalpha():
                student_last_name = input("What is the student's last name?")

        course_name = input("Please enter the name of the course: ")
        student_data = {"FirstName": student_first_name,
                        "LastName": student_last_name,
                        "CourseName": course_name}
        students.append(student_data)
        continue

    # Present the current data
    elif menu_choice == "2":
        print("Here is the current data: \n")
        for student in students:
            message = '{},{},{}'
            print(message.format(message.format(student_data["FirstName"], student_data["LastName"], student_data["CourseName"])))
        continue

    # Save the data to a file
    elif menu_choice == "3":
        try:
            file = open(FILE_NAME, "w")
            json.dump(student, file)
            file.close()
        except Exception as e:
            print("Error saving data")
            print(e)
        finally:
            if file and not file.closed:
                file.close()
                print("The following data was saved to file!")
            for student in students:
                message = "{},{},{}"
                print(message.format(student_data["FirstName"], student_data["LastName"], student_data["CourseName"]))
        continue

    # Stop the loop
    elif menu_choice == "4":
        input("Press enter to end program")
        break  # out of the loop
    else:
        print("Please only choose option 1, 2, or 3")

print("Program Ended")
